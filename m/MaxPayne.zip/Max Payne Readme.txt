Information:
Source: Max Payne
Count: ~5300
Palette: PNG
Format: Patches/Flats
Description: Textures from Max Payne

Credits:
Conversion: Clonehunter
Author: Remedy
Submitted: Clonehunter

Description: 
All major textures from Max Payne.  Some are kinda large, but could still be useful.  Sorry for filesize, but these are kind of high-res.  No Playermodle textures this time around though :P